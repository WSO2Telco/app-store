# DefaultApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**locationDelete**](DefaultApi.md#locationDelete) | **DELETE** /location | 
[**locationGet**](DefaultApi.md#locationGet) | **GET** /location | 
[**locationHead**](DefaultApi.md#locationHead) | **HEAD** /location | 
[**locationPatch**](DefaultApi.md#locationPatch) | **PATCH** /location | 
[**locationPost**](DefaultApi.md#locationPost) | **POST** /location | 
[**locationPut**](DefaultApi.md#locationPut) | **PUT** /location | 


<a name="locationDelete"></a>
# **locationDelete**
> locationDelete()



### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.location.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    apiInstance.locationDelete();
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#locationDelete");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="locationGet"></a>
# **locationGet**
> locationGet()



### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.location.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    apiInstance.locationGet();
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#locationGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="locationHead"></a>
# **locationHead**
> locationHead()



### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.location.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    apiInstance.locationHead();
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#locationHead");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="locationPatch"></a>
# **locationPatch**
> locationPatch(payload)



### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.location.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Payload2 payload = new Payload2(); // Payload2 | Request Body
try {
    apiInstance.locationPatch(payload);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#locationPatch");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **payload** | [**Payload2**](Payload2.md)| Request Body | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="locationPost"></a>
# **locationPost**
> locationPost(payload)



### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.location.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Payload1 payload = new Payload1(); // Payload1 | Request Body
try {
    apiInstance.locationPost(payload);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#locationPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **payload** | [**Payload1**](Payload1.md)| Request Body | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="locationPut"></a>
# **locationPut**
> locationPut(payload)



### Example
```java
// Import classes:
//import org.wso2.client.api.ApiException;
//import org.wso2.client.api.location.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
Payload payload = new Payload(); // Payload | Request Body
try {
    apiInstance.locationPut(payload);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#locationPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **payload** | [**Payload**](Payload.md)| Request Body | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

